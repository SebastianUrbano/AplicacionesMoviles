package com.example.listaslibreta;

import android.content.Intent;
import android.os.Bundle;

import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ListView;
import android.widget.Toast;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

public class MainActivity extends AppCompatActivity {

    //private EditText nameEt;
    //  private EditText telEt;

    private EditText textoBusqueda;

    private ImageButton botonBusqueda;
    private FloatingActionButton btnAgregarPlaylist;
    private ListView contactList;
    private PlaylistAdapter adapter;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Toolbar mToolbar = findViewById(R.id.toolbar2);
        mToolbar.setTitle("         " +
                "NDeezer");
        //   nameEt = findViewById(R.id.name_et);
        //  telEt = findViewById(R.id.tel_et);
        botonBusqueda = findViewById(R.id.buscar_button);
        textoBusqueda = findViewById(R.id.buscar_edit_text);


        btnAgregarPlaylist = findViewById(R.id.btn_agregar_playlist);
        contactList = findViewById(R.id.contact_list);

        adapter = new PlaylistAdapter();
        contactList.setAdapter(adapter);


        btnAgregarPlaylist.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {


                Intent myIntent = new Intent(getApplicationContext(), CrearPlaylistActivity.class);
                startActivityForResult(myIntent, 11);


            }
        });

    }


    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        if (requestCode == 11 && resultCode == RESULT_OK) {

            String nombreLista = data.getExtras().getString("nombreLista");
            String nombreUsuario = data.getExtras().getString("nombreUsuario");
            String descripcion = data.getExtras().getString("descripcion");

            Playlist p = new Playlist(nombreLista, nombreUsuario, descripcion, 0);
            // Playlist c = new Playlist("Sisa", "Sisa", "erre", 11);



            adapter.addPlaylist(p);


            Toast.makeText(this, "" + nombreLista, Toast.LENGTH_SHORT).show();


        }
    }


}
