package com.example.listaslibreta;

public class Playlist {

    private String nombreDeLista;
    private String nombreDeUsuario, descripcion;
    private int numeroDeItems;
    //private ArrayList<Cancion> canciones;------------------------------------------------ HACER

    public Playlist(String nombreDeLista, String nombreDeUsuario, String descripcion, int numeroDeItems) {
        this.nombreDeLista = nombreDeLista;
        this.nombreDeUsuario = nombreDeUsuario;
        this.descripcion = descripcion;
        this.numeroDeItems = numeroDeItems;
    }

    public String getNombreDeLista() {
        return nombreDeLista;
    }

    public void setNombreDeLista(String nombreDeLista) {
        this.nombreDeLista = nombreDeLista;
    }

    public String getNombreDeUsuario() {
        return nombreDeUsuario;
    }

    public void setNombreDeUsuario(String nombreDeUsuario) {
        this.nombreDeUsuario = nombreDeUsuario;
    }

    public String getDescripcion() {
        return descripcion;
    }

    public void setDescripcion(String descripcion) {
        this.descripcion = descripcion;
    }

    public int getNumeroDeItems() {
        return numeroDeItems;
    }

    public void aumentarNumeroDeCanciones() {
        setNumeroDeItems(numeroDeItems++);
    }

    public void disminuirNumeroDeCanciones() {
        if (numeroDeItems > 0) {
            setNumeroDeItems(numeroDeItems--);

        }
    }

    public void setNumeroDeItems(int numeroDeItems) {
        this.numeroDeItems = numeroDeItems;
    }
}
